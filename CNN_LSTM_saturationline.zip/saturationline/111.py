# -*- coding: utf-8 -*-
import pandas as pd
import  numpy as np
df=pd.read_csv(r'C:\Users\23723\Desktop\T_Wms_Day.csv',encoding='unicode_escape')
df=df.drop(['time'],axis=1)
df=df.dropna()
print(df.head())
data,cityName=df.A, df.ID

from sklearn.cluster import KMeans
km = KMeans(n_clusters=4)
data=np.array(data).reshape(-1,1)
label = km.fit_predict(data)


# 定义4个簇
km = KMeans(n_clusters=4)
# 计算簇中心以及为簇分配序号
label = km.fit_predict(data)
#print(cityName)
# 计算花费
expenses = np.sum(km.cluster_centers_, axis=1)
print('-----')
print(expenses)

# 定义二维列表，按类盛放城市名称

CityCluster = [[], [], [], []]
# 将城市按照label分成设定的簇
# try:
for i in range(len(cityName)):  #len(cityName)
    CityCluster[label[i]].append(cityName[i])
for i in range(len(CityCluster)):
    print("Expenses:%.2f" % expenses[i])
    print(CityCluster[i])
# except Exception as e :
#     print(e)
# 将城市名输出，将城市的花费输出


