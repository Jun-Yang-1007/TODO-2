import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
from sklearn.preprocessing import MinMaxScaler
from sklearn.metrics import r2_score
from keras.models import Sequential
from keras.layers import Dense
from keras.callbacks import EarlyStopping
from keras.optimizers import Adam
from keras.layers import LSTM,SimpleRNN,GRU
import pandas as pd
import time
from sklearn.metrics import mean_squared_error,mean_absolute_error,r2_score,mean_squared_log_error
df = pd.read_csv('C:/Users/41634/Desktop/paper/newdata.csv',sep=',', index_col=0)
df = df.dropna()
import pandas as pd
from keras.metrics import mape, rmse

df=df[['date','NO.8']]
df=df.dropna()
#df.drop(['Open', 'High', 'Low', 'Close', 'Volume'], axis=1, inplace=True)

df['date'] = pd.to_datetime(df['date'])

df = df.set_index(['date'], drop=True)

df.head(10)

split_date = int(df.shape[0]*0.8)
split_date
#split_date = pd.Timestamp('2019/5/01 16:58:01')

# df =  df['NO.8']


train = df[:split_date]
print(train.shape)
test = df[split_date:]
print(test.shape)
plt.figure(figsize=(10, 6))


scaler = MinMaxScaler(feature_range=(-1, 1))
train=np.array(train)
test=np.array(test)
train=train.reshape(-1,1)
test=test.reshape(-1,1)

# train_sc = scaler.fit_transform(train)
# test_sc = scaler.transform(test)
train_sc =  train
test_sc = test

X_train = train_sc[:-1]
y_train = train_sc[1:]
X_test = test_sc[:-1]
y_test = test_sc[1:]

# # ANN
# nn_model = Sequential()
# nn_model.add(Dense(100, input_dim=1, activation='relu'))
# nn_model.add(Dense(1))
# nn_model.compile(loss='mean_squared_error', optimizer='adam',metrics=['mape','rmse'])
# early_stop = EarlyStopping(monitor='loss', patience=4, verbose=1)
#
# #当监测到loss停止改进时，结束训练。
# history = nn_model.fit(X_train, y_train, epochs=10, batch_size=7, verbose=1,  callbacks=[early_stop],shuffle=False,)
# y_pred_test_nn = nn_model.predict(X_test)
# y_train_pred_nn = nn_model.predict(X_train)
# print("The R2 score on the Train set is:\t{:0.3f}".format(r2_score(y_train, y_train_pred_nn)))
# print("The R2 score on the Test set is:\t{:0.3f}".format(r2_score(y_test, y_pred_test_nn)))
#
# print('rmse:',np.sqrt(np.mean((y_test - y_pred_test_nn )**2)))
# print('maeRLR:',np.mean(abs(y_test - y_pred_test_nn  ))   )
# print('mape:', 100*np.mean(np.abs((y_test - y_pred_test_nn ) / np.abs(y_test), None)))



#SVR

from sklearn.svm import SVR #导入需要的模块
start_time = time.time()
#clf = SVR()
SVR = SVR(gamma='auto', C=1.0, epsilon=0.2)
SVR = SVR.fit(X_train,y_train) #用训练集数据训练模型
result = SVR.score(X_test,y_test)
SVR_PREDICT = SVR.predict(X_test)
end_time = time.time()
timeconsuming = end_time- start_time
print(timeconsuming)
import keras.backend as K
# SVR_PREDICT= K.constant(SVR_PREDICT)
SVR_PREDICT = SVR_PREDICT.reshape(-1,1)
print('SVR',result)
print('rmse:',np.sqrt(np.mean((y_test - SVR_PREDICT)**2)))
print('maeSVR:',np.mean(abs(y_test - SVR_PREDICT ))   )
print('mape:', 100*np.mean(np.abs((y_test - SVR_PREDICT) / np.abs(y_test), None)))
print('****************')

from sklearn.tree import DecisionTreeRegressor
DT = DecisionTreeRegressor()
DT= DT.fit(X_train,y_train)
DT_score=DT.score(X_test,y_test)
predict2 = DT.predict(X_test)
DT_PREDICT = DT.predict(X_test)
DT_PREDICT = DT_PREDICT.reshape(-1,1)
print('DT score:',DT_score)
print('rmse:',np.sqrt(np.mean((y_test - DT_PREDICT)**2)))
print('maeDT:',np.mean(abs(y_test - DT_PREDICT))   )
print('mape:', 100*np.mean(np.abs((y_test - DT_PREDICT  ) / np.abs(y_test), None)))


from sklearn.ensemble import RandomForestRegressor
rlr = RandomForestRegressor(random_state=1)
rlr = rlr.fit(X_train,y_train)
score1=rlr.score(X_test,y_test)
predict2 = rlr.predict(X_test)
rlr_PREDICT = rlr .predict(X_test)
rlr_PREDICT = rlr_PREDICT.reshape(-1,1)
print('rfrscore:',score1)
print('rmse:',np.sqrt(np.mean((y_test - predict2 )**2)))
print('maeRLR:',np.mean(abs(y_test - predict2 ))   )
print('mape:', 100*np.mean(np.abs((y_test - predict2 ) / np.abs(y_test), None)))
print('****************')

plt.plot(DT_PREDICT, label='predict_data2', linewidth='0.8', c='blue')
plt.plot(rlr_PREDICT, label='predict_data2', linewidth='0.8', c='pink')
plt.plot(SVR_PREDICT, label='predict_data2', linewidth='0.8', c='r')
plt.plot(y_test, label='raw_data', linewidth='1', c='black')
plt.legend()
plt.show()



from sklearn.model_selection import train_test_split,cross_val_score
from keras.layers.convolutional import MaxPooling1D, Conv1D
from keras.layers import Dense,LSTM,Activation
model = Sequential()
model.add(SimpleRNN(input_dim=1, output_dim=1, return_sequences = True))
model.add(SimpleRNN(units=50))
model.add(Dense(1))  # 修改
model.add(Activation('linear'))  # 修改
# model.add(Dense(units=1, kernel_initializer='normal', activation='sigmoid'))
model.compile(loss='rmse', optimizer='adam', metrics=['mae', 'rmse'])
model.fit(X_train, y_train, batch_size=32, epochs=12, validation_split=0.2,shuffle=False)  # ,callbacks=[tensorboard]   32
predict1 = model.predict(y_test)

#      plt.plot(predict1, label='predict_data', linewidth='0.3', c='green')      #将不同结果放在一起，一个真实值，两种预测值
#     plt.plot(test_y, label='raw_data', linewidth='0.4', c='darkorange')
#     plt.legend()
#      plt.show()

print('SimpleRNNscore:',r2_score(y_test, predict1))
print('RNNrmse:',np.sqrt(np.mean((y_test - predict1 )**2)))
print('maeRLR:',np.mean(abs(y_test - predict1 ))   )
print('mape:', 100*np.mean(np.abs((y_test - predict1 ) / np.abs(y_test), None)))