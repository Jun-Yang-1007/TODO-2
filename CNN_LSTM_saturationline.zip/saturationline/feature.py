import time
import tensorflow as tf
from tensorflow.keras.models import Sequential
from tensorflow.keras.layers import Dense, Dropout, Activation, Flatten, Conv2D, MaxPooling2D
import pickle
from tensorflow.keras.callbacks import TensorBoard
import time
import pandas as pd
import numpy as np

import pandas as pd
import numpy as np
from sklearn.preprocessing import MinMaxScaler
from sklearn.metrics import mean_squared_error,mean_absolute_error,r2_score
import warnings
import keras

warnings.filterwarnings('ignore')
from keras.models import Sequential
from keras.layers import LSTM, Dense, Activation
import matplotlib.pyplot as plt
from keras import regularizers

from sklearn.model_selection import train_test_split


# gpu_options = tf.GPUOptions(per_process_gpu_memory_fraction=0.33)
# sess = tf.Session(config=tf.ConfigProto(gpu_options=gpu_options))
def load_data(filename):
    df = pd.read_csv(filename, index_col=0)
    # df = df.drop(['ID', 'time','C','D','B'], axis=1)
    df = df.replace(to_replace="----", value=np.nan)
    # df = df.drop(['A', 'B', 'C', 'D'], axis=1)
    df = df.dropna()
    data_all = np.array(df).astype('float')
    print(data_all.shape)  # (877, 1)

    # 数据归一化
    MMS = MinMaxScaler()
    data_all = MMS.fit_transform(data_all)
    print(data_all.shape)  # 877，1
    # 构造输入lstm的3D数据：（133， 11， 1）

    data = []
    for i in range(len(data_all) - 84 - 1):
        data.append(data_all[i: i + 84 + 1])
    # global reshaped_data
    reshaped_data = np.array(data).astype('float64')
    print('reshaped_data.shape', reshaped_data.shape)  # (877, 4, 1)

    # 对133组数据处理，每组11个数据，前10个作为特征，第11个是数值标签：（133， 10，1）
    x = reshaped_data[:, :-1]
    print('samples shape:', x.shape, '\n')  # (877, 3, 1)
    y = reshaped_data[:, -1]
    print('labels shape:', y.shape, '\n')  # (873, 1)

    train_x, test_x, train_y, test_y = train_test_split(x, y, test_size=0.3, random_state=42)
    print(train_x.shape, test_x.shape, train_y.shape, test_y.shape)
    return train_x, train_y, test_x, test_y, MMS


filename = 'C:/Users/23723/Desktop/one-value.csv'
train_x, train_y, test_x, test_y, MMS = load_data(filename)

# train multiple models
dense_layers = [1, 2, 3]
layer_sizes = [32, 64, 128]
#LSTM_layers = [10, 15, 20]
# conv_layers = [1, 2, 3]

i=1
if i< len(dense_layers)*len(layer_sizes)+1:
    for dense_layer in dense_layers:
        for layer_size in layer_sizes:
            #for LSTM_layer in LSTM_layers:
                model_name = "{}-LSTM-{}-nodes-{}-dense-{}".format(1, layer_size, dense_layer, int(time.time()))
                tensorboard = TensorBoard(log_dir='logs/{}'.format(model_name))
                print(model_name)

                model = Sequential()
                model.add(LSTM(layer_size, input_shape=(84, 1)))

                model.add(Activation("relu"))

                # for l in range(LSTM_layer):
                #     model.add(LSTM(layer_size))
                #     model.add(Activation("relu"))

                for l in range(dense_layer):
                    model.add(Dense(layer_size))
                    model.add(Activation("relu"))

                model.add(Dense(1))
                model.add(Activation("relu"))

                model.compile(loss="mse",
                              optimizer="adam")  #

                model.fit(train_x, train_y, batch_size=128, epochs=10, validation_split=0.2, callbacks=[tensorboard])
                print('finish')
    i+=1