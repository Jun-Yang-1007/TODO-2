#https://zhuanlan.zhihu.com/p/94889284
import pandas as pd
import numpy as np
np.set_printoptions(threshold=np.inf) #设置np数据在打印时能够完整输出，方便观察
from keras.models import Sequential
from keras.layers import LSTM,Dense,regularizers,GRU
import keras
import matplotlib.pyplot as plt
from sklearn.metrics import  r2_score


#使用模型时再用
filepath = './my_model_11'
my_model = keras.models.load_model(filepath+'.h5')
model_2=my_model


# 全局参数，所有要调整的参数都在这里
dim=300 #输出维度数，也是LSTM的网络节点数
epochs=30 #500 #训练代数（可以理解为训练次数）
days=20 #读取多少天的数据作为一次预测。例如读取20天的历史数据来预测未来1天的情况
batch_size = 128 #训练批次大小，就是一次性读取多少个样本进行一次运算，越大运算速度越快，但是占用内存和显存越大，根据自己的机器性能设置。同时该参数还决定梯度下降算法的下降步长数。


def mape(y_true,y_pred):
    return np.mean(np.abs((y_pred-y_true)/y_true))*100


# 开始构建网络
n_steps = days #输入张量的维度数
n_features = 1 #输入张量的维度
model_2 = Sequential()
# 激活函数用relu
model_2.add(GRU(dim, activation='relu',input_shape=(84, n_features)))    #84为预测前的步长，n_features为输出的维度，这里只有1维，Dense的可以改
# 输出层使用全连接层，只要一个输出节点
model_2.add(Dense(1))     #n_steps_out 为输出的 y 每次考虑几个时间步
#选择优化器和损失函数，优化器为线性规划算法，损失函数用的是高维空间测定距离的函数
model_2.compile(optimizer='adam', loss='mape')

data=pd.read_csv(r'C:/Users/23723/Desktop/saturationline.csv',index_col=0)
data=data.loc[:,['time','value']]
data=data[0:1000]


#data=data.drop(['B','C','D','E','F','TIME'],axis=1)
data['time']=pd.to_datetime(data['time'])
data = data.replace(to_replace="----", value=np.nan)
data = data.dropna()
# data_all = np.array(data).astype('float')
#print(data_all.shape)  # (877, 1)
df=data.set_index('time')
plt.plot(df.value)
plt.show()


#构建两个处理数据生成张量表的函数，一个用带标签输出，另外一个只处理输入数据集，生成20x5的切片数据。
def processData(data,lb):         #lb是20
    lb=84
    X,Y = [],[]
    for i in range(len(data)-lb-1):
        X.append(data[i:(i+lb)])
        #X.append((data[i:i+lb,0]))
        try:
            # Y.append(data[(i+2+lb),0])
            Y.append(data[(i+2+lb),:])
        except:
            Y.append(data[(i+lb),:])
            #Y.append(data[(i+lb),0])
    return np.array(X),np.array(Y)

def pData(data,lb):
    lb = 84
    X = []
    for i in range(len(data)-lb-1):
        X.append(data[i:(i+lb)])
    return np.array(X)


from sklearn.preprocessing import MinMaxScaler
close = data['value']
cl = np.array(close)
cl = cl.reshape(cl.shape[0],1)
scl = MinMaxScaler()
sc2 = MinMaxScaler()
cl = scl.fit_transform(cl)

# 生成标签
_,y = processData(cl,days)
X = data.value
X=X.reshape(-1,1)

X = sc2.fit_transform(X)
X = pData(X,days)

y_train,y_test = y[:int(y.shape[0]*0.8)],y[int(y.shape[0]*0.8):]
X_train,X_test = X[:int(X.shape[0]*0.8)],X[int(X.shape[0]*0.8):]

random_state=200
#执行模型训练
history = model_2.fit(X_train, y_train, batch_size=batch_size, nb_epoch=epochs, validation_split=0.2, verbose=1)
predict = model_2.predict(X_train)
predict = np.reshape(predict, (predict.size,))  # 变成向量
test_y = np.reshape(y_test, (y_test.size,))
plt.plot(history.history['loss'], label='train')
plt.plot(history.history['val_loss'], label='test')
plt.legend(['train', 'test'])
plt.show()

'''
#随机从测试集中抽取一个单一数据切片进行预测
act = []
pred = []
import random
i=random.randint(0,130)
Xt = model_2.predict(X_test[i].reshape(1,84,1))
print('预测值:{0}, 实际值:{1}'.format(Xt,y_test[i].reshape(-1,1)))
pred.append(Xt)
act.append(y_test[i])


# 将测试集中的所有切片以序列的方式进行预测，查看预测结果与真实值的拟合情况。
Xt = model_2.predict(X_test)
fig = plt.gcf()
plt.plot(y_test.reshape(-1,1),label='y_test')
plt.plot(Xt,label='Forecast')
plt.legend()
plt.show()
a = y_test.reshape(-1,1)
b = Xt
c = a - b #实际值减去预测值
c = pd.DataFrame(c)
print(c.describe())

print("The R2 on the Train set is:\t{:0.3f}".format(r2_score(y_train, predict)))
print("The R2 on the Test set is:\t{:0.3f}".format(r2_score(y_test, Xt)))

#切勿覆盖高质量模型
#path='./my_model_11' # 请自行设置存储路径及文件名，     #The R2 on the Train set is:0.919   Test set is:	0.847
# path='./drybeach' # 请自行设置存储路径及文件名，     #The R2 on the Train set is:0.880   Test set is:	0.843
# model_2.save(path+'.h5',include_optimizer=True) # 保存模型本体
# model_2.save_weights(path + '_weights.h5') # 保存模型权重



i=1
while i < len(X_test[0:20]):
    p_1 = my_model.predict(X_test[0:20])  # len(X_test)=1633
    p_1 = scl.inverse_transform(p_1)
    print(f'第{i}天',f'预测值为:{np.round(p_1[i],4)}')
    file='D:/WORK/saturationline/file.csv'
    # 保存至file文件中，index=False表示文件中不添加索引，header=False表示不添加列名，mode='a+'表示在已有数据基础上添加新数据，并不覆盖已有数据
    nums = pd.DataFrame(np.round(p_1[i],4))
    print(nums)
    nums.to_csv(file, index=False, mode='a+', header=False)
    i+=1
else:
    print('已经全预测完')
df = pd.read_csv('D:/WORK/saturationline/file.csv', header=None, names=['value','new_data'])
#data = pd.DataFrame({'a':np.round(p_1[i],4), 'b': [4, 5, 6]})
#df.to_csv('D:/WORK/saturationline/file.csv', index=False)
'''