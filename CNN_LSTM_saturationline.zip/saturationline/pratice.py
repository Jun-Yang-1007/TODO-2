import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
from keras.models import Sequential
from keras.layers import Dense,LSTM,Activation
from sklearn.preprocessing import MinMaxScaler
import tensorflow as tf
from keras.callbacks import  TensorBoard
import  warnings
import random
from sklearn.metrics import  r2_score,precision_score
from keras.metrics import mape,rmse,mae
from keras.layers.convolutional import MaxPooling1D, Conv1D
from keras.layers import  Flatten,RepeatVector
from tensorflow.keras.callbacks import TensorBoard
import seaborn as sns
import time
warnings.filterwarnings('ignore')
import math
import datetime
start = time.time()

df = pd.read_csv('C:/Users/41634/Desktop/paper/newdata.csv',sep=',')
# df = pd.read_csv('./Day.csv',sep=',', index_col=0)
df = df.replace(to_replace="----", value=np.nan)
df = df.dropna()

df['date']=pd.to_datetime(df['date'])
df = df.set_index('date')

#df=df.value
df=df['NO.21']

# sns.kdeplot(df,shade=True,cbar=True)
# plt.show()


data_all=np.array(df).astype(float)

data=[]
for i in range(len(data_all)- 9):
    data.append(data_all[i:i+ 10])
reshaped_data=np.array(data).astype(float)
MMS=MinMaxScaler()

x=reshaped_data[:,:-1]
print(x.shape)
y=reshaped_data[:,-1]
y=y.reshape(-1,1)
print(y.shape)
x=MMS.fit_transform(x)
y=MMS.fit_transform(y)

split_boundary=int(reshaped_data.shape[0]*0.8)
train_x=x[:split_boundary]
test_x=x[split_boundary:]
train_y=y[:split_boundary]
test_y=y[split_boundary:]

train_x=np.reshape(train_x,(train_x.shape[0], train_x.shape[1],1))
test_x=np.reshape(test_x,(test_x.shape[0],test_x.shape[1],1))


with tf.name_scope("LSTM_layers"):
#     # 1
#     model=Sequential()
#     model.add(LSTM(input_dim=1, output_dim=10,return_sequences=True))
#
#     model.add(LSTM(50))
#     model.add(Dense(1))
#     model.add(Activation('linear'))
#     model.compile(loss='rmse', optimizer='adam',metrics=['mape','rmse'])
#     model.fit(train_x, train_y, batch_size=64, epochs=60, validation_split=0.2,
#               shuffle=False)  # ,callbacks=[tensorboard]   32
#     predict1 = model.predict(test_x)
#     predict1 = MMS.inverse_transform(predict1)
#     test_y1 = MMS.inverse_transform(test_y)
#     print(r2_score(test_y1, predict1))
#     plt.plot(predict1, label='predict_data', linewidth='0.3', c='green')      #将不同结果放在一起，一个真实值，两种预测值
#     plt.plot(test_y1, label='raw_data', linewidth='0.4', c='darkorange')
#     plt.legend()
#     plt.show()


   # 2
            model = Sequential()
            model.add(Conv1D(filters=16, kernel_size=1, padding='same', strides=1, activation='linear', input_shape=(9,1)))
            model.add(Conv1D(filters=32,kernel_size=1))
            model.add(MaxPooling1D(pool_size=1))
            # model.add(LSTM(input_dim=1, output_dim=1, return_sequences=True))
            model.add(LSTM(units=50))

           # model.add(LSTM(units=700))
            # model.add(Flatten())
            # 可以把LSTM和Flatten删除,仅保留LSTM
            # model.add(LSTM(units=3)) 
            #model.add(Dense(5, activation='relu'))

            # 在lstm层之后可以添加隐含层，也可以不加，直接加输出层
            # model.add(Dense(units=4,kernel_initializer='normal',activation='relu')) 
            model.add(Dense(1))   #修改
            model.add(Activation('linear')) #修改
            # model.add(Dense(units=1, kernel_initializer='normal', activation='sigmoid'))
            model.compile(loss='rmse', optimizer='adam',metrics=['mae','rmse'])
            model.fit(train_x, train_y, batch_size=32, epochs=1, validation_split=0.2, shuffle=False)  # ,callbacks=[tensorboard]   32
            predict1 = model.predict(test_x)
            predict1 = MMS.inverse_transform(predict1)
            test_y1 = MMS.inverse_transform(test_y)
      #      plt.plot(predict1, label='predict_data', linewidth='0.3', c='green')      #将不同结果放在一起，一个真实值，两种预测值
       #     plt.plot(test_y, label='raw_data', linewidth='0.4', c='darkorange')
       #     plt.legend()
      #      plt.show()
            print(r2_score(test_y1, predict1))

# 复制2
#             model = Sequential()
#             model.add(Conv1D(filters=64, kernel_size=1, activation='linear', input_shape=(9,1)))
#             model.add(MaxPooling1D(pool_size=1))
#             model.add(Flatten())
#             model.add(RepeatVector(1))   # 将输入重复一次
#             model.add(LSTM(5, activation='linear', return_sequences=True))
#             model.add(LSTM(10, activation='linear', return_sequences=True))
#             model.add(Flatten())
#             model.add(Dense(1))
#             model.compile(loss='rmse', optimizer='adam', metrics=['mae','rmse','mape'])
#
#
#             model.fit(train_x,train_y,batch_size=128, epochs=5,validation_split=0.2) #,callbacks=[tensorboar
#             predict1 = model.predict(test_x)
#             predict1 = MMS.inverse_transform(predict1)
#             test_y1 = MMS.inverse_transform(test_y)
#filters 参数是您将拥有多少个不同的窗口 .  （所有这些都具有相同的长度，即 kernel_size ） . 您想要生成多少个不同的结果或渠道 .

#当您使用 filters=100 和 kernel_size=4 时，您将创建100个不同的过滤器，每个过滤器的长度为4.结果将带来100个不同的卷积 .


    # 3
    #def build_model_cnn_lstm(n_timesteps, n_features, gru_nodes, filters=2 , n_series =1):
            LSTM_layers = [50]
            Conv1D_layers = [64]
            i = 1
         #   if i < len(LSTM_layers)* len(Conv1D_layers)+1:
            for LSTM_layer in LSTM_layers:
                for Conv1D_layer in Conv1D_layers:
                    model_name = "LSTM-{}-nodes-{}-dense-{}".format(LSTM_layer,Conv1D_layer,datetime.datetime.now().strftime(datetime.datetime.now().strftime("%Y-%m-%d-%H-%M-%S")))  #
                    global tensorboard
                    tensorboard = TensorBoard(log_dir='logs/{}'.format(model_name))
                    print(model_name)
                    model = Sequential()
                    model.add(Conv1D(filters=Conv1D_layer, kernel_size=1, activation='linear', input_shape=(9,1)))
                    model.add(MaxPooling1D(pool_size=1))
                    model.add(Flatten())
                    model.add(RepeatVector(1))   # 将输入重复一次
                    model.add(LSTM(25, activation='linear', return_sequences=True))
                    model.add(LSTM(LSTM_layer, activation='linear', return_sequences=True))
                    model.add(LSTM(25, activation='linear', return_sequences=True))
                    model.add(Flatten())
                    model.add(Dense(1))
                    model.compile(loss='rmse', optimizer='adam', metrics=['mae','rmse','mape'])
                    print(model.summary())
                    i+=1

                    model.fit(train_x,train_y,batch_size=64, epochs=1,validation_split=0.2) #,callbacks=[tensorboard]   32
                    predict2=model.predict(test_x)
                    predict2=MMS.inverse_transform(predict2)
                    test_y2=MMS.inverse_transform(test_y)
                    plt.figure(dpi=300)
                    plt.plot(predict1, label='predict_data1', linewidth='0.4', c='red')   #将不同结果放在一起，一个真实值，两种预测值
                    plt.plot(predict2, label='predict_data2', linewidth='0.4', c = 'blue')
                    plt.plot(test_y2, label='raw_data', linewidth='0.4', c = 'green')
                    plt.legend()
                    plt.show()

                    print(r2_score(test_y1, predict1))
                    print(r2_score(test_y2, predict2))
                    print('mae1:', np.mean(abs(test_y1 - predict1)))
                    print('mae2:', np.mean(abs(test_y2 - predict2)))


    # model = Sequential()
    # model.add(LSTM(input_shape=(9,1), output_dim=1, return_sequences=True))
    # model.add(Conv1D(filters=2, kernel_size=1, activation='linear', input_shape=(9,1)))
    # model.add(MaxPooling1D(pool_size=1))
    # model.add(Flatten())
    # # model.add(RepeatVector(1))
    # # model.add(LSTM(1, activation='linear', return_sequences=True))
    # # model.add(Flatten())
    # model.add(Dense(1))
    # model.compile(loss='mse', optimizer='adam', metrics=['mae'])


# random.seed(100)
# # with tf.variable_scope('lstm_nn', initializer=lstm_init):
# init = tf.global_variables_initializer()
# with tf.Session() as sess:
#     sess.run(init)
    #file_writer = tf.summary.FileWriter('./logs/1', sess.graph)
    #TensorBoard= TensorBoard(log_dir='logs/2')
            # model.fit(train_x,train_y,batch_size=64, epochs=120,validation_split=0.2) #,callbacks=[tensorboard]   32
            # predict=model.predict(test_x)
            # predict=MMS.inverse_transform(predict)
            # test_y=MMS.inverse_transform(test_y)
            # plt.plot(predict, label='predict_data', linewidth='0.3', c = 'green')
            # plt.plot(test_y, label='raw_data', linewidth='0.4', c = 'darkorange')
            # plt.legend()
            # plt.show()
            # print(r2_score(test_y , predict))

end = time.time()
print(f'消耗时间{end-start}')

def change(number):
    A  = []
    for num in number:
        A.append(num[0])
    return A

predict = change(predict2)
test_y = change(test_y)


data = {"predict_data": predict, 'raw_data': test_y}
data = pd.DataFrame(data)
sns.lmplot(y='raw_data', x='predict_data', data=data, line_kws={'color':'#01a2d9','alpha':0.2},scatter_kws={ 's':1, 'color':'darkorange', 'alpha':0.7},ci=95,markers=['+'])
#sns.stripplot(y='raw_data', x='predict_data', data=data)
plt.show()

