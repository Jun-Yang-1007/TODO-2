import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
from keras.models import Sequential
from keras.layers import Dense,LSTM,Activation,GRU,SimpleRNN,Dropout
from sklearn.preprocessing import MinMaxScaler
#from keras.metrics import mean_absolute_error,mape1
import tensorflow as tf
from keras.callbacks import  TensorBoard
import  warnings
import random
warnings.filterwarnings('ignore')
random.seed(100)

df = pd.read_csv('C:/Users/41634/Desktop/fushandata/daily.csv',sep=',', index_col=0)
df = df.replace(to_replace="----", value=np.nan)
df = df.dropna()
#df = df[113:]
df = df.fillna(method='ffill')
df['DATETIME']=pd.to_datetime(df['DATETIME'])

MMS=MinMaxScaler()
#df=df[['value','E']]               #改成2维要改三处：df=np.array(df).reshape(-1,1);
                                    # train_x=np.reshape(train_x,(train_x.shape[0], train_x.shape[1],1))
                                    #test_x=np.reshape(test_x,(test_x.shape[0],test_x.shape[1],1))
                                    #Dense(1)
                                    # input shape
df=df['F_TP']
df=np.array(df).reshape(-1,1)
data_all=np.array(df).astype(float)
data_all=MMS.fit_transform(data_all)
print(data_all.shape)


# x,y=[],[]
# for i in range(len(data_all)- 10 -1):
#     #data.append(data_all[i:i+ 10])
#     end_ix = i + 10
#     if end_ix > 10 - 1:
#         break
#     x, y = 10[i:end_ix], 10[end_ix]
#     x.append(x)
#     y.append(y)


# x=reshaped_data[:,:-1]
# print('x.shape',x.shape)
# y=reshaped_data[:,-1]
# # y=y.reshape(-1,1)
# print('y.shape',y.shape)

def split_sequence(data_all, n_steps):
    X, y = list(), list()
    for i in range(len(data_all)):
        # find the end of this pattern
        end_ix = i + n_steps
        # check if we are beyond the sequence
        if end_ix > len(data_all)-1:
            break
        # gather input and output parts of the pattern
        seq_x, seq_y = data_all[i:end_ix], data_all[end_ix]
        X.append(seq_x)
        y.append(seq_y)
    return np.array(X), np.array(y)

x, y = split_sequence(data_all, 10)
print(x.shape,y.shape)

split_boundary=int(data_all.shape[0]*0.8)
print(split_boundary)

train_x=x[:int(split_boundary*0.8)]
test_x=x[split_boundary:]
train_y=y[:int(split_boundary*0.8)]
test_y=y[split_boundary:]

valid_x= x[len(train_x):len(train_x)+int(split_boundary*0.2), :]
valid_y= y[len(train_x):len(train_x)+int(split_boundary*0.2), :]
print(valid_x.shape, valid_y.shape)


train_x=np.reshape(train_x,(train_x.shape[0], train_x.shape[1],1))
test_x=np.reshape(test_x,(test_x.shape[0],test_x.shape[1],1))
valid_x = valid_x.reshape((valid_x.shape[0], valid_x.shape[1],1))
print(f'train_x.shape:{train_x.shape}',f'test_x.shape{test_x.shape}')


# #choose model to predict
cell_type = 'LSTM'
model = Sequential()
if cell_type == 'LSTM':
    # model.add(LSTM(100, return_sequences=True, input_dim=train_x.shape[-1], input_length=train_x.shape[1]))
   # model.add(LSTM(50))
   # model.add(Dropout(0.2))

    model.add(LSTM(20, input_dim=1))
if cell_type == 'GRU':
    model.add(GRU(100, return_sequences=True, input_dim=train_x.shape[-1], input_length=train_x.shape[1]))
    model.add(GRU(50))
if cell_type == 'RNN':
    model.add(SimpleRNN(100, return_sequences=True, input_dim=train_x.shape[-1], input_length=train_x.shape[1]))
    model.add(SimpleRNN(50))

#model.add(keras.layers.Dropout(rate=0.2)
model.add(Dense(1))
model.compile(loss='mse', optimizer='adam')

history = model.fit(train_x, train_y, nb_epoch=60, batch_size=12, validation_split=0.2)
predict = model.predict(test_x)
predict = np.reshape(predict, (predict.size,))  # 变成向量
test_y = np.reshape(test_y, (test_y.size,))
plt.plot(history.history['loss'], label='train')
plt.plot(history.history['val_loss'], label='test')
plt.legend(['train', 'test'])
plt.show()

random.seed(100)
init = tf.global_variables_initializer()
with tf.Session() as sess:
    sess.run(init)
    # file_writer = tf.summary.FileWriter('./logs/1', sess.graph)
    # TensorBoard= TensorBoard(log_dir='logs/2')
    model.fit(train_x,train_y,batch_size=1, epochs=1,validation_data=(valid_x,valid_y)) #callbacks=[TensorBoard]


# def get_forest_input(train_x,train_y):
#     train_x=train_x[train_x.shape[0]-1][train_x.shape[1]-1]
#     train_y=train_y[train_y[0]-1]
#     input=[]
#     for i in range(10):
#         input.append(train_x[i])
#     for i in range(10):
#         input.append(train_y[i])
#     input=np.reshape(input,(1,1,10))
#     return  input
#
#     train_x, train=get_forest_input(train_x,train_y)

    # predict=model.predict(test_x)
    # predict=MMS.inverse_transform(predict)
    # test_y=MMS.inverse_transform(test_y)
    # plt.plot(predict,label='predict')
    # plt.plot(test_y,label='test_y')
    # plt.legend()
    # plt.show()

    #plt.figure(figsize=(12, 8))
    '''
    train_predict = model.predict(train_x)
    valid_predict = model.predict(valid_x)
    test_predict = model.predict(test_x)
    plt.plot(data_all[:, -1], c='b')

    plt.plot([None for _ in train_predict], c='g')

    plt.plot([None for _ in train_predict] + [x for x in test_predict], c='y',label='predict')

    plt.plot([None for _ in train_predict] + [None for _ in valid_predict] + [x for x in test_predict], c='r',label='all')
    plt.legend()
    plt.show()
    '''
