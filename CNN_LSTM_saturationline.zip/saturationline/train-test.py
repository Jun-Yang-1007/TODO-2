#https://www.cnblogs.com/always-fight/p/10133068.html

import pandas as pd
import numpy as np
from sklearn.preprocessing import MinMaxScaler
from sklearn.metrics import r2_score
import warnings
import keras
warnings.filterwarnings('ignore')
from keras.models import Sequential
from keras.layers import LSTM, Dense, Activation
import matplotlib.pyplot as plt
from keras import regularizers
from train import build_model,train_model
from sklearn.model_selection import train_test_split


class LSTM_predict:
    def __init__(self, filename, sequence_length=84, split=0.5):
        self.filename = filename
        self.sequence_length = sequence_length
        self.split = split

    def load_data(self):
        df = pd.read_csv(filename,index_col=0)
        #df = df.drop(['ID', 'time','C','D','B'], axis=1)
        df = df.replace(to_replace="----", value=np.nan)
        #df = df.drop(['A', 'B', 'C', 'D'], axis=1)
        df = df.dropna()
        data_all = np.array(df).astype('float')
        print(data_all.shape)  # (877, 1)

        # 数据归一化
        MMS = MinMaxScaler()
        data_all = MMS.fit_transform(data_all)
        print(data_all.shape)         #877，1
        # 构造输入lstm的3D数据：（133， 11， 1）

        data = []
        for i in range(len(data_all) - self.sequence_length - 1):
            data.append(data_all[i: i + self.sequence_length + 1])
         # global reshaped_data
        reshaped_data = np.array(data).astype('float64')
        print('reshaped_data.shape',reshaped_data.shape)  # (877, 4, 1)

        # 对133组数据处理，每组11个数据，前10个作为特征，第11个是数值标签：（133， 10，1）
        x = reshaped_data[:, :-1]
        print('samples shape:', x.shape, '\n')  # (877, 3, 1)
        y = reshaped_data[:, -1]
        print('labels shape:', y.shape, '\n')  # (873, 1)

        # # 构建训练集
        # split_boundary = int(reshaped_data.shape[0] * self.split)
        # train_x = x[:split_boundary]
        # # 构建测试集
        # test_x = x[split_boundary:]
        # print('test_x shape:', test_x.shape)     #175，3，1
        # #加不加下面两行都一样，由于原数据已经是这样的形状
        # #train_x = np.reshape(train_x, (train_x.shape[0], train_x.shape[1], 1))
        # #test_x = np.reshape(test_x, (test_x.shape[0], test_x.shape[1], 1))
        # # 训练集标签
        # train_y = y[: split_boundary]
        # print('train_y shape', train_y.shape)    #698，1
        # #print('train_y', train_y)  # 698，1
        # # 测试集标签
        # test_y = y[split_boundary:]
        # print('test_y shape', test_y.shape)      #175，1

        train_x,  test_x, train_y,test_y =train_test_split(x, y, test_size = 0.5, random_state = 42)
        print(train_x.shape,test_x.shape,train_y.shape,test_y.shape)
        return train_x, train_y, test_x, test_y , MMS




if __name__ == '__main__':
    filename = 'C:/Users/41634/Desktop/fushandata/daily.csv'
    LSTM_predict = LSTM_predict(filename)
    train_x, train_y, test_x, test_y,MMS = LSTM_predict.load_data()
    predict_y, test_y = train_model(train_x, train_y, test_x, test_y)
    fig2 = plt.figure(2)

    predict_y = MMS.inverse_transform([[i] for i in predict_y])
    test_y = MMS.inverse_transform([[i] for i in test_y])

    plt.plot(predict_y, 'g:', label='prediction')
    plt.plot(test_y, 'r-', label='True')
    plt.title('This pic is drawed using Standard_Inversed Data')
    plt.legend(['predict', 'true'])
    plt.show()


