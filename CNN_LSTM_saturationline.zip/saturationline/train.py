import pandas as pd
import numpy as np
from sklearn.preprocessing import MinMaxScaler
import warnings
import keras
warnings.filterwarnings('ignore')
from keras.models import Sequential
from keras.layers import LSTM, Dense, Activation,Dropout,BatchNormalization
import matplotlib.pyplot as plt
from keras import regularizers
from sklearn.metrics import mean_squared_error,mean_absolute_error,r2_score
import math

def build_model():
    # LSTM函数的input_dim参数是输入的train_x的最后一个维度
    # train_x的维度为(n_samples, time_sequence_steps, input_dim)
    # 在keras 的官方文档中，说了LSTM是整个Recurrent层实现的一个具体类，它需要的输入数据维度是：
    # 形如（samples，timesteps，input_dim）的3D张量
    # 而这个time_sequence_steps就是我们采用的时间窗口，即把一个时间序列当成一条长链，我们固定一个一定长度的窗口对这个长链进行采用
    # 这里使用了两个LSTM进行叠加，第二个LSTM的第一个参数指的是输入的维度，这和第一个LSTM的输出维度并不一样，这也是LSTM比较随意的地方
    # 最后一层采用了线性层

    # model = Sequential()
    # model.add(LSTM(input_dim=1, output_dim=10,return_sequences=True))
    # model.add(LSTM(100, return_sequences=False, kernel_regularizer=regularizers.l2(0.02))) #, dropout=0.2
    # model.add(BatchNormalization(center=True, scale=True, beta_regularizer=regularizers.l2(0.01),
    #                              gamma_regularizer=regularizers.l2(0.01),
    #                              beta_constraint='max_norm', gamma_constraint='max_norm'))
    # model.add(Dense(output_dim=1))
    # model.add(Activation('tanh'))
    # model.add(Dropout(0.5))
    # #model.add(LSTM(50,return_sequences=False, dropout=0.2))
    # model.compile(loss='mae', optimizer='adam')  #rmsprop
    # model.save_weights('my_model_weights.h5')
    # print("model layers:", model.layers)
    # model.summary()

    #2
    model = Sequential()
    # 激活函数用relu
    model.add(LSTM(300, activation='relu', input_shape=(84, 1)))
    # 输出层使用全连接层，只要一个输出节点
    model.add(Dense(1))
    # model.add(LSTM(32, return_sequences=True,
    #                input_shape=(timesteps, data_dim)))  # 返回维度为 32 的向量序列
    # model.add(LSTM(32, return_sequences=True))  # 返回维度为 32 的向量序列
    # model.add(LSTM(32))  # 返回维度为 32 的单个向量
    # model.add(Dense(10, activation='softmax'))

    # 选择优化器和损失函数，优化器为线性规划算法，损失函数用的是高维空间测定距离的函数
    model.add(Activation('linear'))
    model.compile(loss='mae',optimizer='adam')
    return model

def train_model( train_x, train_y, test_x, test_y):
    model = build_model()
    try:
        # history = LossHistory()
        history=model.fit(train_x,train_y,nb_epoch=10,batch_size=128,validation_split=0.2)
        predict = model.predict(test_x)
        predict = np.reshape(predict, (predict.size,))  # 变成向量
        test_y = np.reshape(test_y, (test_y.size,))
        plt.plot(history.history['loss'], label='train')
        plt.plot(history.history['val_loss'], label='test')
        plt.legend(['train', 'test'])
        plt.show()

    except KeyboardInterrupt:
        # print('predict:', predict)
        # print('test_y', test_y)
        print('KeyboardInterrupt')

    try:
        fig1 = plt.figure(1)
        plt.plot(predict, 'r')
        plt.plot(test_y, 'g-')
        plt.title('This pic is drawed using Standard Data')
        plt.legend(['predict', 'true'])

    except Exception as e:
        print(e)
    y_pred_test_nn = model.predict(test_x)
    y_train_pred_nn = model.predict(train_x)
    print("The mean_absolute_error on the Train set is:\t{:0.3f}".format(mean_absolute_error(train_y, y_train_pred_nn)))
    print("The mean_absolute_error on the Test set is:\t{:0.3f}".format(mean_absolute_error(test_y, y_pred_test_nn)))
    print("The R2 on the Train set is:\t{:0.3f}".format(r2_score(train_y, y_train_pred_nn)))
    print("The R2 on the Test set is:\t{:0.3f}".format(r2_score(test_y, y_pred_test_nn)))
    plt.plot(y_pred_test_nn,test_x)
    plt.show()
    return predict, test_y

