import numpy as np
import matplotlib.pyplot as plt
import pandas as pd
import pywt
import statsmodels.api as sm
from statsmodels.tsa.ar_model import AR
from statsmodels.tsa.arima_model import ARIMA
from statsmodels.tsa.arima_model import ARMA


import logging
import time
import os




def preTest(start , end):

    df = pd.read_csv('C:/Users/41634/Desktop/fushandata/daily.csv')
    df = df[start:end]
    # df = pd.read_csv('C:/Users/41634/Desktop/paper/newdata.csv')
    # df = df[:800]
    df = df.dropna()   # 没有去空值 则 IndexError: index 0 is out of bounds for axis 0 with size 0
    df['DATETIME'] = pd.to_datetime(df['DATETIME'])

    index_list = np.array(df['F_TN'])[:-20] # 最后20个用来预测
    date_list1 = np.array(df['DATETIME'])[:-20]

    index_for_predict = np.array(df['F_TN'])[-20:] # 预测的真实值序列
    date_list2 = np.array(df['DATETIME'])[-20:]

# 分解
    A2,D2,D1 = pywt.wavedec(index_list, 'db4', mode='sym', level=2)  # 分解得到第四层低频部分系数和全部4层高频部分系数
    coeff = [A2,D2,D1]

# 对每层小波系数求解模型系数p,q
    order_A2 = sm.tsa.arma_order_select_ic(A2, ic= 'aic')['aic_min_order']
    order_D2 = sm.tsa.arma_order_select_ic(D2, ic= 'aic')['aic_min_order']
    order_D1 = sm.tsa.arma_order_select_ic(D1, ic= 'aic')['aic_min_order']

    print(order_A2,order_D2,order_D1)
# 构建模型
    # 有时候用AIC准则求解的模型参数来建模会报错，需要调节数据时间长度
    model_A2 = ARMA(A2, order=order_A2)
    model_D2 = ARMA(D2, order=order_D2)
    model_D1 = ARMA(D1, order=order_D1)

    results_A2 = model_A2.fit()
    results_D2 = model_D2.fit()
    results_D1 = model_D1.fit()

    plt.figure(figsize=(10,15),dpi=300)
    # plt.subplot(3,1,1)
    plt.plot(A2, label= 'A2', linewidth='0.6', c= 'green')
    plt.plot(results_A2.fittedvalues, label= 'results_A2.fittedvalues', linewidth='0.4', c= 'red')
    plt.title('model_A2')
    plt.legend()
    plt.show()
    # plt.subplot(3,1,2)
    plt.plot(D2,label= 'D2', linewidth='0.6', c= 'green')
    plt.plot(results_D2.fittedvalues, label= 'results_D2.fittedvalues', linewidth='0.4', c= 'red')
    plt.title('model_D2')
    plt.legend()
    plt.show()
    # plt.subplot(3,1,3)
    plt.plot(D1, label= 'D1', linewidth='0.6', c= 'green')
    plt.plot(results_D1.fittedvalues,label= 'results_D1.fittedvalues', linewidth='0.4', c= 'red')
    plt.title('model_D1')
    plt.legend()
    plt.show()

#    接着，目标为预测最后20个数据，我们得求出每个小波系数ARMA模型需要预测多少步。方法就是查看所有数据小波分解后的系数个数并求出差值，具体如下
    A2_all, D2_all, D1_all = pywt.wavedec(np.array(df['F_TN']), 'db4', mode='sym',level=2) # 对所有序列分解
    delta = [len(A2_all)-len(A2), len(D2_all)-len(D2), len(D1_all)-len(D1)] # 求出差值，则delta序列对应的每层小波系数ARMA模型需要预测的步数
    print('*****************')
    print(delta)
# 预测小波系数 包括in-sample 和Out-sample的需要预测的小波系数
    pA2 = model_A2.predict(params=results_A2.params, start=1, end=len(A2)+delta[0])
    pD2 = model_D2.predict(params=results_D2.params, start=1, end=len(D2)+delta[1])
    pD1 = model_A2.predict(params=results_D1.params, start=1, end=len(D1)+delta[2])
    # 重构
    coeff_new = [pA2,pD2,pD1]
    denoised_index = pywt.waverec(coeff_new,'db4')


    plt.plot(index_list,label= 'index_list', linewidth='0.6', c= 'blue')
    plt.plot(denoised_index,label= 'denoised_index', linewidth='0.6', c= 'red')
    plt.legend()
    plt.show()

# 20个预测值
    temp_data_wt = {'real_value':index_for_predict, 'pre_value_wt': denoised_index[-20:], 'err_wt':denoised_index[-20:]-index_for_predict,
                    'err_rate':(denoised_index[-20:]-index_for_predict)/index_for_predict}
    predict_wt = pd.DataFrame(temp_data_wt, index = date_list2 ,columns=['real_value','pre_value_wt','err_wt','err_rate'])
    print(predict_wt)
    return predict_wt


if __name__ == '__main__':
    df = pd.read_csv('C:/Users/41634/Desktop/fushandata/daily.csv')
    # df = df['F_TN']
    # df = df.dropna()
    # df['DATETIME'] = pd.to_datetime(df['DATETIME'])
    preTest(0,500)
    log_creater('./')

