#-*- coding: utf-8 -*-
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
df=pd.read_csv('C:/Users/41634/Desktop/paper/lx.csv')
#df=df[1578:]
# df=pd.read_csv('C:/Users/41634/Desktop/paper/newdata.csv')
def process(data):
    data=data.replace(to_replace='----',value=np.nan)
    return data
df = process(df)
df=df.dropna()
df['date'] = pd.to_datetime(df['date'])
# print(df[['NO.8','NO.13','NO.21','NO.28','NO.33']]).head()


#df=df.loc[:,['date','eight','thirteen','twentyone','twentyeight','thirtythree']]
df.set_index('date')
plt.figure(figsize=(10, 6))

plt.plot(df['NO.21'][1578:4000])
#plt.plot(df['NO.13'][:4000],c='g')
# plt.plot(df['NO.21'][:4000],c='r')
#plt.plot(df['NO.28'][:4000])
#plt.plot(df['NO.33'][:4000])
plt.legend
plt.show()




'''
import numpy as np
import matplotlib.pyplot as plt
import pandas as pd
import seaborn as sns
import warnings

warnings.filterwarnings('ignore')

data = df

M = []
NUM = []


def box(data):
    sns.boxplot(data, whis=1.5)
    plt.show()
    s = pd.Series(data)

    print('平均数：', s.median())
    print('')
    print('下四分位数：', s.quantile(0.25))
    print('')
    print('中位数:', s.quantile(0.5))
    print('')
    print('上四分位数：', s.quantile(0.75))
    Q3 = s.quantile(0.75)
    Q1 = s.quantile(0.25)
    IQR = s.quantile(0.75) - s.quantile(0.25)

    high = Q3 + 1.5 * IQR
    low = Q1 - 1.5 * IQR
    print(high, low)
    print('--------------\n')

    for i, num in enumerate(data):
        if num < low or num > high:
            print('索引为:{},值为：{}'.format(i, num))  # 真正的数从第3行开始。  0为第一行
            M.append(i)
            NUM.append(num)
    return None


box(data=df['NO.8'])
test2 = list(df['NO.8'])
print('---', len(test2))

for number in NUM:
    test2.remove(number)
    df = df[~df['NO.8'].isin([number])]
print('++++++', len(test2))
print(len(df))
M.clear()
NUM.clear()
print('------------------')


box(data=df['NO.13'])
test2 = list(df['NO.13'])
print('---', len(test2))

for number in NUM:
    test2.remove(number)
    df = df[~df['NO.13'].isin([number])]
print('++++++', len(test2))
print(len(df))
M.clear()
NUM.clear()
print('------------------')


box(data=df['NO.17'])
test2 = list(df['NO.17'])
print('---', len(test2))

for number in NUM:
    test2.remove(number)
    df = df[~df['NO.17'].isin([number])]
print('++++++', len(test2))
print(len(df))
M.clear()
NUM.clear()
print('------------------')

box(data=df['NO.21'])
test2 = list(df['NO.21'])
print('---', len(test2))

for number in NUM:
    test2.remove(number)
    df = df[~df['NO.21'].isin([number])]
print('++++++', len(test2))
print(len(df))
M.clear()
NUM.clear()
print('------------------')

box(data=df['NO.28'])
test2 = list(df['NO.28'])
print('---', len(test2))

for number in NUM:
    test2.remove(number)
    df = df[~df['NO.28'].isin([number])]
print('++++++', len(test2))
print(len(df))
M.clear()
NUM.clear()
print('------------------')

box(data=df['NO.33'])
test2 = list(df['NO.33'])
print('---', len(test2))

for number in NUM:
    test2.remove(number)
    df = df[~df['NO.33'].isin([number])]
print('++++++', len(test2))
print(len(df))
M.clear()
NUM.clear()
print('------------------')

print(number)

df.to_csv('./newdata.csv')
'''