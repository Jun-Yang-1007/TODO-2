# coding: utf-8
#ANN LSTM对比
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
from sklearn.preprocessing import MinMaxScaler
from sklearn.metrics import r2_score
from keras.models import Sequential
from keras.layers import Dense
from keras.callbacks import EarlyStopping
from keras.optimizers import Adam
from keras.layers import LSTM

df = pd.read_csv('C:/Users/23723/Desktop/one-value.csv')
df['date'] = pd.to_datetime(df['date'])
#df = df.set_index(['date'], drop=True)
print(df.head(5))
df=df.replace(to_replace="----",value=np.nan)
df=df.dropna()
df =df['value']


train = df.iloc[:13000]
test = df.iloc[13000:]
X_train = train[:-1]
y_train = train[1:]
X_test = test[:-1]
y_test = test[1:]

X_train=np.array(X_train)
y_train=np.array(y_train)
X_test=np.array(X_test)
y_test=np.array(y_test)

#
# def mape1(y_pred,y_true):
#     return np.mean(abs((y_pred-y_true)/y_true))*100


X_train_lmse = np.reshape(X_train, (X_train.shape[0], 1, 1))
X_test_lmse = np.reshape(X_test, (X_test.shape[0], 1,1))
lstm_model = Sequential()
lstm_model.add(LSTM(100, input_shape=(1, X_train_lmse.shape[1]), activation='relu', kernel_initializer='lecun_uniform', return_sequences=False))
lstm_model.add(Dense(1))
lstm_model.compile(loss='mse', optimizer='adam')
early_stop = EarlyStopping(monitor='loss', patience=2, verbose=1)
history_lstm_model = lstm_model.fit(X_train_lmse, y_train, epochs=1, batch_size=64, verbose=1, shuffle=False, callbacks=[early_stop])



y_pred_test_lstm = lstm_model.predict(X_test_lmse)
y_train_pred_lstm = lstm_model.predict(X_train_lmse)
print("The R2 score on the Train set is:\t{:0.3f}".format(r2_score(y_train, y_train_pred_lstm)))
print("The R2 score on the Test set is:\t{:0.3f}".format(r2_score(y_test, y_pred_test_lstm)))

print(r2_score(y_train,X_train))




