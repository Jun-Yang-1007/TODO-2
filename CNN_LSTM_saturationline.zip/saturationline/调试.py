import random
from sklearn.metrics import r2_score, precision_score
from keras.metrics import mape, rmse, mae
from keras.layers.convolutional import MaxPooling1D, Conv1D
from keras.layers import Flatten, RepeatVector
import pandas as pd
import seaborn as sns
import time
import numpy as np
import math
import datetime
import matplotlib.pyplot as plt

start = time.time()

df = pd.read_csv('C:/Users/41634/Desktop/paper/newdata.csv', sep=',', index_col=0)
# df = pd.read_csv('./Day.csv',sep=',', index_col=0)
df = df.replace(to_replace="----", value=np.nan)
df = df.dropna()

df['date'] = pd.to_datetime(df['date'])
df = df.set_index('date')

colors2 = [
    "blue",
    "orange",
    "green",
    "red",
    "purple",
    #    "brown",
    "pink",
    #    "gray",
    #    "olive",
    #    "cyan",
]

colors2 = [
    "darkorange"
]
def show_raw_visualization(data):
 #   time_data = data[date_time_key]
    fig, axes = plt.subplots(
        nrows=2, ncols=3, figsize=(30, 15), dpi=200, facecolor="w", edgecolor="k" )
    for i in range(len(data.columns)):
        key = df.columns[i]
        c = colors2[i % (len(colors2))]
        t_data = data[key]
   #     t_data = len(df['NO.8'])
      #  t_data.index = date
 #       t_data.head()
        ax = t_data.plot(
            ax=axes[i // 3, i % 3],
            color=c,
            title="{}".format( key),
            rot=25,
        )
        ax.legend([key])
    plt.tight_layout()
    plt.show()

show_raw_visualization(df)


# plt.figure(figsize=(30, 18))
# plt.subplot(3, 3, 1)
# plt.plot(df['NO.8'], c='blue')
# plt.title('NO.33')
#
# plt.subplot(3, 3, 2)
# plt.plot(df['NO.13'], color='red')  # df['date'],
# plt.title('NO13')
#
# plt.subplot(3, 3, 3)
# plt.plot(df['NO.17'], color='red')  # df['date'],
# plt.title('NO.17')
#
# plt.subplot(3, 3, 3)
# plt.plot(df['NO.21'], color='red')  # df['date'],
# plt.title('NO.17')
#
# plt.show()
